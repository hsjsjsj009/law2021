# How To Run Service
1. Compression Service
```go
go run services/compress/main.go
```
2. CRUD service
```go
go run services/crud/main.go
```
3. Storage service
```go
go run services/storage/main.go
```
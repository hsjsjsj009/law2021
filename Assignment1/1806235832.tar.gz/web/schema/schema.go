package schema

type InputData struct {
	Key string `json:"key"`
	Data string `json:"data"`
}

package constant

const (
	ExchangeName = "1806235832"
	ExchangeType = "direct"
	GRPCPort = ":7001"
)

